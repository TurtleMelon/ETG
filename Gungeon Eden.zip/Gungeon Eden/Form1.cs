﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gungeon_Eden
{
    public partial class EtG : Form
    {
        public EtG()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            int guns = r.Next(1, 192);
            int items = r.Next(1, 216);
            int character = r.Next(1, 6);

            switch (character)
            {
                case 1:
                    pictureBox3.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\characters\\Bullet.png";
                    label3.Text = "The Bullet".ToString();
                    break;

                case 2:
                    pictureBox3.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\characters\\Convict.png";
                    label3.Text = "The Convict".ToString();
                    break;

                case 3:
                    pictureBox3.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\characters\\Hunter.png";
                    label3.Text = "The Hunter".ToString();
                    break;

                case 4:
                    pictureBox3.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\characters\\Marine.png";
                    label3.Text = "The Marine".ToString();
                    break;

                case 5:
                    pictureBox3.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\characters\\Pilot.png";
                    label3.Text = "The Pilot".ToString();
                    break;

                case 6:
                    pictureBox3.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\characters\\Robot.png";
                    label3.Text = "The Robot".ToString();
                    break;
            }

            switch (guns)
            {
                case 1:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\32px-Black_Hole_Gun.png";
                    label1.Text = "Black Hole Gun".ToString();
                    break;
                case 2:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\32px-Fightsabre.png";
                    label1.Text = "Fightsabre".ToString();
                    break;
                case 3:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\32px-Hexagun.png";
                    label1.Text = "Hexagun".ToString();
                    break;
                case 4:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\32px-M16.png";
                    label1.Text = "M16".ToString();
                    break;
                case 5:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\32px-Molotov_Launcher.png";
                    label1.Text = "Molotov Launcher".ToString();
                    break;
                case 6:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\32px-Prototype_Railgun.png";
                    label1.Text = "Prototype Railgun".ToString();
                    break;
                case 7:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\32px-Railgun.png";
                    label1.Text = "Railgun".ToString();
                    break;
                case 8:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\32px-RC_Rocket.png";
                    label1.Text = "RC Rocket".ToString();
                    break;
                case 9:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\32px-Siren.png";
                    label1.Text = "Siren".ToString();
                    break;
                case 10:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\32px-Strafe_Gun.png";
                    label1.Text = "Strafe Gun".ToString();
                    break;
                case 11:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\32px-Trident.png";
                    label1.Text = "Trident".ToString();
                    break;
                case 12:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\32px-Winchester_Rifle.png";
                    label1.Text = "Winchester Rifle".ToString();
                    break;
                case 13:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Casey.png";
                    label1.Text = "Casey".ToString();
                    break;
                case 14:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Pea_Shooter.png";
                    label1.Text = "Pea Shooter".ToString();
                    break;
                case 15:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\38_Special.png";
                    label1.Text = "38 Special".ToString();
                    break;
                case 16:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Derringer.png";
                    label1.Text = "Derringer".ToString();
                    break;
                case 17:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Unfinished_Gun.png";
                    label1.Text = "Unfinished Gun".ToString();
                    break;
                case 18:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Bullet_(Gun).png";
                    label1.Text = "Bullet".ToString();
                    break;
                case 19:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Hyper_Light_Blaster.png";
                    label1.Text = "Hyper Light Blaster".ToString();
                    break;
                case 20:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Shell.png";
                    label1.Text = "Shell".ToString();
                    break;
                case 21:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Makarov.png";
                    label1.Text = "Makarov".ToString();
                    break;
                case 22:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\M1911.png";
                    label1.Text = "M1911".ToString();
                    break;
                case 23:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Magnum.png";
                    label1.Text = "Magnum".ToString();
                    break;
                case 24:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Colt_1851.png";
                    label1.Text = "Colt 1851".ToString();
                    break;
                case 25:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\SAA.png";
                    label1.Text = "SAA".ToString();
                    break;
                case 26:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Cold_45.png";
                    label1.Text = "Cold 45".ToString();
                    break;
                case 27:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Polaris.png";
                    label1.Text = "Polaris".ToString();
                    break;
                case 28:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Jolter.png";
                    label1.Text = "Jolter".ToString();
                    break;
                case 29:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Dungeon_Eagle.png";
                    label1.Text = "Dungeon Eagle".ToString();
                    break;
                case 30:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Grey_Mauser_(Gun).png";
                    label1.Text = "Grey Mauser".ToString();
                    break;
                case 31:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Vorpal_Gun.png";
                    label1.Text = "Vorpal Gun".ToString();
                    break;
                case 32:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Dueling_Pistol.png";
                    label1.Text = "Dueling Pistol".ToString();
                    break;
                case 33:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\AU_Gun.png";
                    label1.Text = "AU Gun".ToString();
                    break;
                case 34:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Big_Iron.png";
                    label1.Text = "Big Iron".ToString();
                    break;
                case 35:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Composite_Gun.png";
                    label1.Text = "Composite Gun".ToString();
                    break;
                case 36:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Flare_Gun.png";
                    label1.Text = "Flare Gun".ToString();
                    break;
                case 37:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Smiley's_Revolver.png";
                    label1.Text = "Smiley's Revolve".ToString();
                    break;
                case 38:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Shades's_Revolver.png";
                    label1.Text = "Shade's Revolver".ToString();
                    break;
                case 39:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Regular_Shotgun.png";
                    label1.Text = "Regular Shotgun".ToString();
                    break;
                case 40:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Old_Goldie.png";
                    label1.Text = "Old Goldie".ToString();
                    break;
                case 41:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Sawed-Off.png";
                    label1.Text = "Sawn-Off".ToString();
                    break;
                case 42:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Winchester.png";
                    label1.Text = "Winchester".ToString();
                    break;
                case 43:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Rattler.png";
                    label1.Text = "Rattler".ToString();
                    break;
                case 44:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Elephant_Gun.png";
                    label1.Text = "Elephant Gun".ToString();
                    break;
                case 45:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Tangler.png";
                    label1.Text = "Tangler".ToString();
                    break;
                case 46:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Void_Shotgun.png";
                    label1.Text = "Void Shotgun".ToString();
                    break;
                case 47:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Mass_Shotgun.png";
                    label1.Text = "Mass Shotgun".ToString();
                    break;
                case 48:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Shotgun_Full_of_Hate.png";
                    label1.Text = "Shotgun Full of Hate".ToString();
                    break;
                case 49:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Shotgun_Full_of_Love.png";
                    label1.Text = "Shotgun Full of Love".ToString();
                    break;
                case 50:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Shotgrub.png";
                    label1.Text = "Shotgrub".ToString();
                    break;
                case 51:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Gilded_Hydra.png";
                    label1.Text = "Gilded Hydra".ToString();
                    break;
                case 52:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Blunderbuss.png";
                    label1.Text = "Blunderbuss".ToString();
                    break;
                case 53:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Pulse_Cannon.png";
                    label1.Text = "Pulse Cannon".ToString();
                    break;
                case 54:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Void_Marshal.png";
                    label1.Text = "Void Marshal".ToString();
                    break;
                case 55:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Zilla_Shotgun.png";
                    label1.Text = "Zilla Shotgun".ToString();
                    break;
                case 56:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Ice_Breaker.png";
                    label1.Text = "Ice Breaker".ToString();
                    break;
                case 57:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\The_Membrane.png";
                    label1.Text = "The Membrane".ToString();
                    break;
                case 58:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Huntsman.png";
                    label1.Text = "Huntsman".ToString();
                    break;
                case 59:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Bow.png";
                    label1.Text = "Bow".ToString();
                    break;
                case 60:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Charmed_Bow.png";
                    label1.Text = "Charm Bow".ToString();
                    break;
                case 61:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Crossbow.png";
                    label1.Text = "Crossbow".ToString();
                    break;
                case 62:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Triple_Crossbow.png";
                    label1.Text = "Triple Crossbow".ToString();
                    break;
                case 63:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Crescent_Crossbow.png";
                    label1.Text = "Cresent Crossbow".ToString();
                    break;
                case 64:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Gunbow.png";
                    label1.Text = "Gunbow".ToString();
                    break;
                case 65:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Klobbe.png";
                    label1.Text = "Klobbe".ToString();
                    break;
                case 66:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Machine_Pistol.png";
                    label1.Text = "Machine Pistol".ToString();
                    break;
                case 67:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Thompson_Sub-Machinegun.png";
                    label1.Text = "Thompson Sub-Machinegun".ToString();
                    break;
                case 68:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\AK-47.png";
                    label1.Text = "AK-47".ToString();
                    break;
                case 69:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\The_Judge.png";
                    label1.Text = "The Judge".ToString();
                    break;
                case 70:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\AKEY-47.png";
                    label1.Text = "AKEY-47".ToString();
                    break;
                case 71:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Crown_of_Guns.png";
                    label1.Text = "Crown of Guns".ToString();
                    break;
                case 72:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Deck4rd.png";
                    label1.Text = "Deck4ard".ToString();
                    break;
                case 73:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Zorgun.png";
                    label1.Text = "Zorgun".ToString();
                    break;
                case 74:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\VertebraeK-47.png";
                    label1.Text = "VertebraeK-47".ToString();
                    break;
                case 75:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Balloon_Gun.png";
                    label1.Text = "Balloon Gun".ToString();
                    break;
                case 76:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\MAC10.png";
                    label1.Text = "MAC10".ToString();
                    break;
                case 77:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Heck_Blaster.png";
                    label1.Text = "Heck Blaster".ToString();
                    break;
                case 78:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Patriot.png";
                    label1.Text = "Patriot".ToString();
                    break;
                case 79:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Vulcan_Cannon.png";
                    label1.Text = "Vulcan Cannon".ToString();
                    break;
                case 80:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Plague_Pistol.png";
                    label1.Text = "Plague Pistol".ToString();
                    break;
                case 81:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Gungine.png";
                    label1.Text = "Gungine".ToString();
                    break;
                case 82:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Dragunfire.png";
                    label1.Text = "Dragunfire".ToString();
                    break;
                case 83:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Sniper_Rifle.png";
                    label1.Text = "Sniper Rifle".ToString();
                    break;
                case 84:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\A.W.P..png";
                    label1.Text = "A.W.P.".ToString();
                    break;
                case 85:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\M1.png";
                    label1.Text = "M1".ToString();
                    break;
                case 86:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Corsair.png";
                    label1.Text = "Cosair".ToString();
                    break;
                case 87:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Mourning_Star.png";
                    label1.Text = "Mourning Star".ToString();
                    break;
                case 88:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Alien_Sidearm.png";
                    label1.Text = "Alien Sidearm".ToString();
                    break;
                case 89:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\RUBE-ADYNE_Prototype.png";
                    label1.Text = "RUBE-ADYNE Prototype".ToString();
                    break;
                case 90:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\RUBE-ADYNE_MK.II.png";
                    label1.Text = "RUBE-ADYNE MKII".ToString();
                    break;
                case 91:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Mine_Cutter.png";
                    label1.Text = "Mine Cutter".ToString();
                    break;
                case 92:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Void_Core_Assault_Rifle.png";
                    label1.Text = "Void Core Assault Rifle".ToString();
                    break;
                case 93:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Flash_Ray.png";
                    label1.Text = "Flash Ray".ToString();
                    break;
                case 94:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Wind_Up_Gun.png";
                    label1.Text = "Wind Up Gun".ToString();
                    break;
                case 95:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\H4mmer.png";
                    label1.Text = "H4mmer".ToString();
                    break;
                case 96:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Snakemaker.png";
                    label1.Text = "Snakemaker".ToString();
                    break;
                case 97:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Hegemony_Carbine.png";
                    label1.Text = "Hegemony Carbine".ToString();
                    break;
                case 98:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Screecher.png";
                    label1.Text = "Screecher".ToString();
                    break;
                case 99:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Laser_Lotus.png";
                    label1.Text = "Laser Lotus".ToString();
                    break;
                case 100:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Hegemony_Rifle.png";
                    label1.Text = "Hegemony Rifle".ToString();
                    break;
                case 101:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Helix.png";
                    label1.Text = "Helix".ToString();
                    break;
                case 102:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Laser_Rifle.png";
                    label1.Text = "Laser Rifle".ToString();
                    break;
                case 103:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Crestfaller.png";
                    label1.Text = "Crestfaller".ToString();
                    break;
                case 104:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Rad_Gun.png";
                    label1.Text = "Rad Gun".ToString();
                    break;
                case 105:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Thunderclap.png";
                    label1.Text = "Thunderclap".ToString();
                    break;
                case 106:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Charge_Shot.png";
                    label1.Text = "Charge Shot".ToString();
                    break;
                case 107:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Dark_Marker.png";
                    label1.Text = "Dark Matter".ToString();
                    break;
                case 108:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Particulator.png";
                    label1.Text = "Particulator".ToString();
                    break;
                case 109:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\The_Emperor.png";
                    label1.Text = "The Emperor".ToString();
                    break;
                case 110:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\RPG.png";
                    label1.Text = "RPG".ToString();
                    break;
                case 111:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Grenade_Launcher.png";
                    label1.Text = "Grenade Launcher".ToString();
                    break;
                case 112:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Stinger.png";
                    label1.Text = "Stinger".ToString();
                    break;
                case 113:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Com4nd0.png";
                    label1.Text = "Com4nd0".ToString();
                    break;
                case 114:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Yari_Launcher.png";
                    label1.Text = "Yari Launcher".ToString();
                    break;
                case 115:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Lil'_Bomber.png";
                    label1.Text = "Lil' Bomber".ToString();
                    break;
                case 116:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Grasschopper.png";
                    label1.Text = "Grasschopper".ToString();
                    break;
                case 117:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Bundle_of_Wands.png";
                    label1.Text = "Bundle Of Wands".ToString();
                    break;
                case 118:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Staff_of_Firepower.png";
                    label1.Text = "Staff of Firepower".ToString();
                    break;
                case 119:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Witch_Pistol.png";
                    label1.Text = "Witch Pistol".ToString();
                    break;
                case 120:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Phoenix.png";
                    label1.Text = "Phoenix".ToString();
                    break;
                case 121:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Magic_Lamp.png";
                    label1.Text = "Magic Lamp".ToString();
                    break;
                case 122:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Gunslinger's_Ashes.png";
                    label1.Text = "Gunslinger's Ashes".ToString();
                    break;
                case 123:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Luxin_Cannon.png";
                    label1.Text = "Luxin Cannon".ToString();
                    break;
                case 124:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Gunther.png";
                    label1.Text = "Gunther".ToString();
                    break;
                case 125:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Unicorn_Horn.png";
                    label1.Text = "Unicorn Horn".ToString();
                    break;
                case 126:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Cobalt_Hammer.png";
                    label1.Text = "Cobalt Hammer".ToString();
                    break;
                case 127:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Bullet_Bore.png";
                    label1.Text = "Bullet Bore".ToString();
                    break;
                case 128:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Cat_Claw.png";
                    label1.Text = "Cat Claw".ToString();
                    break;
                case 129:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Megahand.png";
                    label1.Text = "Megahand".ToString();
                    break;
                case 130:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Demon_Head.png";
                    label1.Text = "Demon Head".ToString();
                    break;
                case 131:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Heroine.png";
                    label1.Text = "Heroine".ToString();
                    break;
                case 132:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Flame_Hand.png";
                    label1.Text = "Flame Hand".ToString();
                    break;
                case 133:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Machine_Fist.png";
                    label1.Text = "Machine Fist".ToString();
                    break;
                case 134:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Robot's_Left_Hand.png";
                    label1.Text = "Robot's Left Hand".ToString();
                    break;
                case 135:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Snowballer.png";
                    label1.Text = "Snowballer".ToString();
                    break;
                case 136:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Super_Meat_Gun.png";
                    label1.Text = "Super Meat Gun".ToString();
                    break;
                case 137:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Anvillain.png";
                    label1.Text = "Anvillian".ToString();
                    break;
                case 138:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Fossilized_Gun.png";
                    label1.Text = "Fossilized Gun".ToString();
                    break;
                case 139:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Gamma_Ray.png";
                    label1.Text = "Gamma Ray".ToString();
                    break;
                case 140:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Freeze_Ray.png";
                    label1.Text = "Freeze Ray".ToString();
                    break;
                case 141:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Science_Cannon.png";
                    label1.Text = "Science Cannon".ToString();
                    break;
                case 142:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Disintegrator.png";
                    label1.Text = "Disintergrator".ToString();
                    break;
                case 143:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Proton_Backpack.png";
                    label1.Text = "Proton Backpack".ToString();
                    break;
                case 144:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Mega_Douser.png";
                    label1.Text = "Mega Douser".ToString();
                    break;
                case 145:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Plunger.png";
                    label1.Text = "Plunger".ToString();
                    break;
                case 146:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Raiden_Coil.png";
                    label1.Text = "Radien Coil".ToString();
                    break;
                case 147:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Moonscraper.png";
                    label1.Text = "Moon Scraper".ToString();
                    break;
                case 148:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Barrel.png";
                    label1.Text = "Barrel".ToString();
                    break;
                case 149:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Trick_Gun.png";
                    label1.Text = "Trick Gun".ToString();
                    break;
                case 150:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Mailbox.png";
                    label1.Text = "Mail Box".ToString();
                    break;
                case 151:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Nail_Gun.png";
                    label1.Text = "Nail Gun".ToString();
                    break;
                case 152:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Light_Gun.png";
                    label1.Text = "Light Gun".ToString();
                    break;
                case 153:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Dueling_Laser.png";
                    label1.Text = "Dueling Laser".ToString();
                    break;
                case 154:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Mahoguny.png";
                    label1.Text = "Mahoguny".ToString();
                    break;
                case 155:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\The_Scrambler.png";
                    label1.Text = "The Scrambler".ToString();
                    break;
                case 156:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Trashcannon.png";
                    label1.Text = "Trashcannon".ToString();
                    break;
                case 157:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Glacier.png";
                    label1.Text = "Glacier".ToString();
                    break;
                case 158:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Origuni.png";
                    label1.Text = "Origuni".ToString();
                    break;
                case 159:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\The_Kiln.png";
                    label1.Text = "The Kiln".ToString();
                    break;
                case 160:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Skull_Spitter.png";
                    label1.Text = "Skull Splitter".ToString();
                    break;
                case 161:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Buzzkill.png";
                    label1.Text = "Buzzkill".ToString();
                    break;
                case 162:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Tear_Jerker.png";
                    label1.Text = "Tear Jerker".ToString();
                    break;
                case 163:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Starpew.png";
                    label1.Text = "Starpew".ToString();
                    break;
                case 164:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Eye_of_the_Beholster.png";
                    label1.Text = "Eye of the Beholster".ToString();
                    break;
                case 165:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Shock_Rifle.png";
                    label1.Text = "Shock Rifle".ToString();
                    break;
                case 166:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Bait_Launcher.png";
                    label1.Text = "Bait Launcher".ToString();
                    break;
                case 167:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Brick_Breaker.png";
                    label1.Text = "Brick Breaker".ToString();
                    break;
                case 168:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Betrayer's_Shield.png";
                    label1.Text = "Betrayer's Shield".ToString();
                    break;
                case 169:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Lower_Case_r.png";
                    label1.Text = "Lower Case r".ToString();
                    break;
                case 170:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Excaliber.png";
                    label1.Text = "Excaliber".ToString();
                    break;
                case 171:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Face_Melter.png";
                    label1.Text = "Face Melter".ToString();
                    break;
                case 172:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Gungeon_Ant.png";
                    label1.Text = "Gungeon Ant".ToString();
                    break;
                case 173:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Abyssal_Tentacle.png";
                    label1.Text = "Abyssal Tentacle".ToString();
                    break;
                case 174:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Quad_Laser.png";
                    label1.Text = "Quad Laser".ToString();
                    break;
                case 175:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Pitchfork.png";
                    label1.Text = "Pitchfork".ToString();
                    break;
                case 176:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Alien_Engine.png";
                    label1.Text = "Alien Engine".ToString();
                    break;
                case 177:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Microtransaction_Gun.png";
                    label1.Text = "Microtransaction Gun".ToString();
                    break;
                case 178:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Poxcannon.png";
                    label1.Text = "Poxcannon".ToString();
                    break;
                case 179:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\T-Shirt_Cannon.png";
                    label1.Text = "Shirt Cannon".ToString();
                    break;
                case 180:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Banana.png";
                    label1.Text = "Banana".ToString();
                    break;
                case 181:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Bee_Hive.png";
                    label1.Text = "Bee Hive".ToString();
                    break;
                case 182:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Silencer.png";
                    label1.Text = "Silencer".ToString();
                    break;
                case 183:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Camera.png";
                    label1.Text = "Camera".ToString();
                    break;
                case 184:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Directional_Pad.png";
                    label1.Text = "Directional Pad".ToString();
                    break;
                case 185:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Gunzheng.png";
                    label1.Text = "Gunzheng".ToString();
                    break;
                case 186:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Sling.png";
                    label1.Text = "Sling".ToString();
                    break;
                case 187:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Cactus.png";
                    label1.Text = "Cactus".ToString();
                    break;
                case 188:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\BSG.png";
                    label1.Text = "BSG".ToString();
                    break;
                case 189:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Compressed_Air_Tank.png";
                    label1.Text = "Compressed Air Tank".ToString();
                    break;
                case 190:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Serious_Cannon.png";
                    label1.Text = "Serious Cannon".ToString();
                    break;
                case 191:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Makeshift_Cannon.png";
                    label1.Text = "Makeshift Cannon".ToString();
                    break;
                case 192:
                    pictureBox1.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\guns\\Devolver.png";
                    label1.Text = "Devolver".ToString();
                    break;
            }
            switch (items)
            {
                case 1:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Meatbun.png";
                    label2.Text = "Meatbun".ToString();
                    break;
                case 2:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Medkit.png";
                    label2.Text = "Medkit".ToString();
                    break;
                case 3:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Ration.png";
                    label2.Text = "Ration".ToString();
                    break;
                case 4:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Orange.png";
                    label2.Text = "Orange".ToString();
                    break;
                case 5:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Bottle.png";
                    label2.Text = "Bottle".ToString();
                    break;
                case 6:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Bomb.png";
                    label2.Text = "Bomb".ToString();
                    break;
                case 7:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Ice_Bomb.png";
                    label2.Text = "Ice Bomb".ToString();
                    break;
                case 8:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Chaff_Grenade.png";
                    label2.Text = "Chaff Grenade".ToString();
                    break;
                case 9:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Proximity_Mine.png";
                    label2.Text = "Proximity Mine".ToString();
                    break;
                case 10:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Cluster_Mine.png";
                    label2.Text = "Cluster Mine".ToString();
                    break;
                case 11:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\C4_(Item).png";
                    label2.Text = "C4".ToString();
                    break;
                case 12:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Molotov.png";
                    label2.Text = "Molotov".ToString();
                    break;
                case 13:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Air_Strike.png";
                    label2.Text = "Air Strike".ToString();
                    break;
                case 14:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Napalm_Strike.png";
                    label2.Text = "Napalm Strike".ToString();
                    break;
                case 15:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Big_Boy.png";
                    label2.Text = "Big Boy".ToString();
                    break;
                case 16:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Roll_Bomb.png";
                    label2.Text = "Roll Bomb".ToString();
                    break;
                case 17:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\iBomb_Companion_App.png";
                    label2.Text = "iBomb Companion App".ToString();
                    break;
                case 18:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Supply_Drop.png";
                    label2.Text = "Supply Drop".ToString();
                    break;
                case 19:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Ammo_Synthesizer.png";
                    label2.Text = "Ammo Synthesizer".ToString();
                    break;
                case 20:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Armor_Synthesizer.png";
                    label2.Text = "Armor Synthesizer".ToString();
                    break;
                case 21:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Heart_Synthesizer.png";
                    label2.Text = "Heart Synthesizer".ToString();
                    break;
                case 22:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Master_of_Unlocking.png";
                    label2.Text = "Master of Unlocking".ToString();
                    break;
                case 23:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Utility_Belt.png";
                    label2.Text = "Utility Belt".ToString();
                    break;
                case 24:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Hidden_Compartment.png";
                    label2.Text = "Hidden Compartment".ToString();
                    break;
                case 25:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Backpack.png";
                    label2.Text = "Backpack".ToString();
                    break;
                case 26:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Scope.png";
                    label2.Text = "Scope".ToString();
                    break;
                case 27:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Laser_Sight.png";
                    label2.Text = "Laser Sight".ToString();
                    break;
                case 28:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Ammo_Belt.png";
                    label2.Text = "Ammo Belt".ToString();
                    break;
                case 29:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Bullet_Time.png";
                    label2.Text = "Bullet Time".ToString();
                    break;
                case 30:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Aged_Bell.png";
                    label2.Text = "Aged Bell".ToString();
                    break;
                case 31:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Singularity.png";
                    label2.Text = "Singularity".ToString();
                    break;
                case 32:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Decoy.png";
                    label2.Text = "Decoy".ToString();
                    break;
                case 33:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Explosive_Decoy.png";
                    label2.Text = "Explosive Decoy".ToString();
                    break;
                case 34:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Melted_Rock.png";
                    label2.Text = "Melted Rock".ToString();
                    break;
                case 35:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Trusty_Lockpicks.png";
                    label2.Text = "Trusty Lockpicks".ToString();
                    break;
                case 36:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Smoke_Bomb.png";
                    label2.Text = "Smoke Bomb".ToString();
                    break;
                case 37:
                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Box.png";
                    label2.Text = "Box".ToString();
                    break;
                case 38:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Fortune's_Favor.png";
                    label2.Text = "Fortune Favor".ToString();
                    break;
                case 39:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Jar_of_Bees.png";
                    label2.Text = "Jar of Bees".ToString();
                    break;
                case 40:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Potion_of_Lead_Skin.png";
                    label2.Text = "Potion of Lead Skin".ToString();
                    break;
                case 41:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Double_Vision.png";
                    label2.Text = "Double Vision".ToString();
                    break;
                case 42:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Relodestone.png";
                    label2.Text = "Reloadstone".ToString();
                    break;
                case 43:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Poison_Vial.png";
                    label2.Text = "Posion Vail".ToString();
                    break;
                case 44:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Potion_of_Gun_Friendship.png";
                    label2.Text = "Potion of Gun Friendship".ToString();
                    break;
                case 45:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Portable_Turret.png";
                    label2.Text = "Portable Turret".ToString();
                    break;
                case 46:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Knife_Shield.png";
                    label2.Text = "Knife Shield".ToString();
                    break;
                case 47:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Grappling_Hook.png";
                    label2.Text = "Grappling Hook".ToString();
                    break;
                case 48:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Stuffed_Star.png";
                    label2.Text = "Stuffed Star".ToString();
                    break;
                case 49:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Boomerang.png";
                    label2.Text = "Boomerang".ToString();
                    break;
                case 50:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Shield_of_the_Maiden.png";
                    label2.Text = "Shield of the Maiden".ToString();
                    break;
                case 51:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\-1_Bullets.png";
                    label2.Text = "+1 Bullets".ToString();
                    break;
                case 52:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Rocket-Powered_Bullets.png";
                    label2.Text = "Rocket-Powered Bullets".ToString();
                    break;
                case 53:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Heavy_Bullets.png";
                    label2.Text = "Heavy Bullets".ToString();
                    break;
                case 54:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Shock_Rounds.png";
                    label2.Text = "Shock Rounds".ToString();
                    break;
                case 55:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Explosive_Rounds.png";
                    label2.Text = "Explosive Rounds".ToString();
                    break;
                case 56:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Ghost_Bullets.png";
                    label2.Text = "Ghost Bullets".ToString();
                    break;
                case 57:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Alpha_Bullet.png";
                    label2.Text = "Alpha Bullets".ToString();
                    break;
                case 58:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Omega_Bullets.png";
                    label2.Text = "Omega Bullets".ToString();
                    break;
                case 59:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Scattershot.png";
                    label2.Text = "Scattershot".ToString();
                    break;
                case 60:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Irradiated_Lead.png";
                    label2.Text = "Irradiated Lead".ToString();
                    break;
                case 61:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Hot_Lead.png";
                    label2.Text = "Hot Lead".ToString();
                    break;
                case 62:
                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Frost_Bullets.png";
                    label2.Text = "Frost Bullets".ToString();
                    break;
                case 63:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Charming_Rounds.png";
                    label2.Text = "Charming Rounds".ToString();
                    break;
                case 64:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Magic_Bullets.png";
                    label2.Text = "Magic Bullets".ToString();
                    break;
                case 65:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Fat_Bullets.png";
                    label2.Text = "Fat Bullets".ToString();
                    break;
                case 66:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Angry_Bullets.png";
                    label2.Text = "Angry Bullets".ToString();
                    break;
                case 67:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Battery_Bullets.png";
                    label2.Text = "Battery Bullets".ToString();
                    break;
                case 68:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Homing_Bullets.png";
                    label2.Text = "Homing Bullets".ToString();
                    break;
                case 69:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Shadow_Bullets.png";
                    label2.Text = "Shadow Bullets".ToString();
                    break;
                case 70:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Easy_Reload_Bullets.png";
                    label2.Text = "Easy Reload Bullets".ToString();
                    break;
                case 71:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Stout_Bullets.png";
                    label2.Text = "Stout Bullets".ToString();
                    break;
                case 72:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Remote_Bullets.png";
                    label2.Text = "Remote Bullets".ToString();
                    break;
                case 73:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Zombie_Bullets.png";
                    label2.Text = "Zombie Bullets".ToString();
                    break;
                case 74:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Flak_Bullets.png";
                    label2.Text = "Flak Bullets".ToString();
                    break;
                case 75:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Silver_Bullets.png";
                    label2.Text = "Silver Bullets".ToString();
                    break;
                case 76:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Gilded_Bullets.png";
                    label2.Text = "Gilded Bullets".ToString();
                    break;
                case 77:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Chaos_Bullets.png";
                    label2.Text = "Chaos Bullets".ToString();
                    break;
                case 78:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Cursed_Bullets.png";
                    label2.Text = "Cursed Bullets".ToString();
                    break;
                case 79:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Chance_Bullets.png";
                    label2.Text = "Chance Bullets".ToString();
                    break;
                case 80:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Helix_Bullets.png";
                    label2.Text = "Helix Bullets".ToString();
                    break;
                case 81:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Bloody_9mm.png";
                    label2.Text = "Bloody 9mm".ToString();
                    break;
                case 82:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Bionic_Leg.png";
                    label2.Text = "Bionic Leg".ToString();
                    break;
                case 83:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Shotgun_Coffee.png";
                    label2.Text = "Shotgun Coffee".ToString();
                    break;
                case 84:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Shotga_Cola.png";
                    label2.Text = "Shotga Cola".ToString();
                    break;
                case 85:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Ballistic_Boots.png";
                    label2.Text = "Ballistic Boots".ToString();
                    break;
                case 86:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Magic_Sweet.png";
                    label2.Text = "Magic Sweet".ToString();
                    break;
                case 87:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Disarming_Personality.png";
                    label2.Text = "Disarming Personality".ToString();
                    break;
                case 88:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Mustache.png";
                    label2.Text = "Mustache".ToString();
                    break;
                case 89:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Lichy_Trigger_Finger.png";
                    label2.Text = "Lichy Trigger Finger".ToString();
                    break;
                case 90:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Enraging_Photo.png";
                    label2.Text = "Enraging Photo".ToString();
                    break;
                case 91:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Ballot.png";
                    label2.Text = "Ballot".ToString();
                    break;
                case 92:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Live_Ammo.png";
                    label2.Text = "Live Ammo".ToString();
                    break;
                case 93:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Eyepatch.png";
                    label2.Text = "Eyepatch".ToString();
                    break;
                case 94:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Cartographer's_Ring.png";
                    label2.Text = "Cartographer's Ring".ToString();
                    break;
                case 95:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Ring_of_Fire_Resistance.png";
                    label2.Text = "Ring of Fire Resistance".ToString();
                    break;
                case 96:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Ring_of_Miserly_Protection.png";
                    label2.Text = "Ring of Miserly Protection".ToString();
                    break;
                case 97:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Unity.png";
                    label2.Text = "Unity".ToString();
                    break;
                case 98:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Ring_of_Chest_Vampirism.png";
                    label2.Text = "Ring of Chest Vampirism".ToString();
                    break;
                case 99:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Cloranthy_Ring.png";
                    label2.Text = "Cloranthy Ring".ToString();
                    break;
                case 100:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Ring_of_Chest_Friendship.png";
                    label2.Text = "Ring of Chest Friendship".ToString();
                    break;
                case 101:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Ring_of_Mimic_Friendship.png";
                    label2.Text = "Ring of Mimic Friendship".ToString();
                    break;
                case 102:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Ring_of_Triggers.png";
                    label2.Text = "Ring of Triggers".ToString();
                    break;
                case 103:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Ring_of_Ethereal_Form.png";
                    label2.Text = "Ring of Ethereal Form".ToString();
                    break;
                case 104:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Gundromeda_Strain.png";
                    label2.Text = "Gundromeda Strain".ToString();
                    break;
                case 105:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Broccoli.png";
                    label2.Text = "Broccoli".ToString();
                    break;
                case 106:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Crutch.png";
                    label2.Text = "Crutch".ToString();
                    break;
                case 107:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Spice.png";
                    label2.Text = "Spice".ToString();
                    break;
                case 108:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Liquid_Valkyrie.png";
                    label2.Text = "Liquid Valkyrie".ToString();
                    break;
                case 109:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Bloody_Eye.png";
                    label2.Text = "Bloody Eye".ToString();
                    break;
                case 110:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Gunknight_Helmet.png";
                    label2.Text = "GunKnight Helment".ToString();
                    break;
                case 111:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Gunknight_Greaves.png";
                    label2.Text = "Gunknight Greaves".ToString();
                    break;
                case 112:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Gunknight_Armor.png";
                    label2.Text = "Gunknight Armor".ToString();
                    break;
                case 113:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Gunknight_Gauntlet.png";
                    label2.Text = "Gunkinght Gauntlet".ToString();
                    break;
                case 114:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Amulet_of_the_Pit_Lord.png";
                    label2.Text = "Amulet of the Pit Lord".ToString();
                    break;
                case 115:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Old_Knight's_Shield.png";
                    label2.Text = "Old Knight's Shield".ToString();
                    break;
                case 116:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Old_Knight's_Helm.png";
                    label2.Text = "Old Knight's Helm".ToString();
                    break;
                case 117:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Old_Knight's_Flask.png";
                    label2.Text = "Old Knight's Flask".ToString();
                    break;
                case 118:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Armor_of_Thorns.png";
                    label2.Text = "Armor of Thorns".ToString();
                    break;
                case 119:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Full_Metal_Jacket.png";
                    label2.Text = "Full Metal Jacket".ToString();
                    break;
                case 120:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Heavy_Boots.png";
                    label2.Text = "Heavy Boots".ToString();
                    break;
                case 121:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Bug_Boots.png";
                    label2.Text = "Bug Boots".ToString();
                    break;
                case 122:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Gunboots.png";
                    label2.Text = "Gunboots".ToString();
                    break;
                case 123:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Springheel_Boots.png";
                    label2.Text = "Springhell Boots".ToString();
                    break;
                case 124:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Coin_Crown.png";
                    label2.Text = "Coin Crown".ToString();
                    break;
                case 125:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Oiled_Cylinder.png";
                    label2.Text = "Oiled Cylinder".ToString();
                    break;
                case 126:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Ice_Cube.png";
                    label2.Text = "Ice Cube".ToString();
                    break;
                case 127:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Rolling_Eye.png";
                    label2.Text = "Rolling Eye".ToString();
                    break;
                case 128:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Cigarettes.png";
                    label2.Text = "Cigarettes".ToString();
                    break;
                case 129:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Charm_Horn.png";
                    label2.Text = "Charm Horn".ToString();
                    break;
                case 130:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Cog_of_Battle.png";
                    label2.Text = "Cog of Battle".ToString();
                    break;
                case 131:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Metronome.png";
                    label2.Text = "Metronome".ToString();
                    break;
                case 132:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Honeycomb.png";
                    label2.Text = "Honeycomb".ToString();
                    break;
                case 133:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Map.png";
                    label2.Text = "Map".ToString();
                    break;
                case 134:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Gungeon_Blueprint.png";
                    label2.Text = "Gungeon Blueprints".ToString();
                    break;
                case 135:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Sense_of_Direction.png";
                    label2.Text = "Sense of Direction".ToString();
                    break;
                case 136:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Duct_Tape.png";
                    label2.Text = "Duct Tape".ToString();
                    break;
                case 137:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Gungeon_Pepper.png";
                    label2.Text = "Gungeon Pepper".ToString();
                    break;
                case 138:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Antibody.png";
                    label2.Text = "Antiboby".ToString();
                    break;
                case 139:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Pink_Guon_Stone.png";
                    label2.Text = "Pink Guon Stone".ToString();
                    break;
                case 140:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\White_Guon_Stone.png";
                    label2.Text = "White Guon Stone".ToString();
                    break;
                case 141:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Orange_Guon_Stone.png";
                    label2.Text = "Orange Guon Stone".ToString();
                    break;
                case 142:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Clear_Guon_Stone.png";
                    label2.Text = "Clear Guon Stone".ToString();
                    break;
                case 143:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Green_Guon_Stone.png";
                    label2.Text = "Green Guon Stone".ToString();
                    break;
                case 144:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Red_Guon_Stone.png";
                    label2.Text = "Red Guon Stone".ToString();
                    break;
                case 145:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Blue_Guon_Stone.png";
                    label2.Text = "Blue Guon Stone".ToString();
                    break;
                case 146:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Iron_Coin.png";
                    label2.Text = "Iron Coin".ToString();
                    break;
                case 147:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Super_Hot_Watch.png";
                    label2.Text = "Super Hot Watch".ToString();
                    break;
                case 148:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Drum_Clip.png";
                    label2.Text = "Drum Clip".ToString();
                    break;
                case 149:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Blood_Brooch.png";
                    label2.Text = "Blood Brooch".ToString();
                    break;
                case 150:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Backup_Gun.png";
                    label2.Text = "Backup Gun".ToString();
                    break;
                case 151:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Sunglasses.png";
                    label2.Text = "Sunglasses".ToString();
                    break;
                case 152:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Mimic_Tooth_Necklace.png";
                    label2.Text = "Mimic Tooth Necklace".ToString();
                    break;
                case 153:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Escape_Rope.png";
                    label2.Text = "Escape Rope".ToString();
                    break;
                case 154:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Jetpack.png";
                    label2.Text = "Jetpack".ToString();
                    break;
                case 155:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Wax_Wings.png";
                    label2.Text = "Wax Wings".ToString();
                    break;
                case 156:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Blast_Helmet.png";
                    label2.Text = "Blast Helmet".ToString();
                    break;
                case 157:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Lament_Configurum.png";
                    label2.Text = "Lament Configurum".ToString();
                    break;
                case 158:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Monster_Blood.png";
                    label2.Text = "Monster Blood".ToString();
                    break;
                case 159:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Nanomachines.png";
                    label2.Text = "Nanomachines".ToString();
                    break;
                case 160:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Seven-Leaf_Clover.png";
                    label2.Text = "Seven-Leaf Clover".ToString();
                    break;
                case 161:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Gold_Ammolet.png";
                    label2.Text = "Gold Ammolet".ToString();
                    break;
                case 162:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Chaos_Ammolet.png";
                    label2.Text = "Chaos Ammolet".ToString();
                    break;
                case 163:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Lodestone_Ammolet.png";
                    label2.Text = "Lodestone Ammotlet".ToString();
                    break;
                case 164:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Uranium_Ammolet.png";
                    label2.Text = "Uranium Ammolet".ToString();
                    break;
                case 165:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Copper_Ammolet.png";
                    label2.Text = "Copper Ammolet".ToString();
                    break;
                case 166:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Frost_Ammolet.png";
                    label2.Text = "Frost Ammolet".ToString();
                    break;
                case 167:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Table_Tech_Sight.png";
                    label2.Text = "Table Tech Sight".ToString();
                    break;
                case 168:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Table_Tech_Money.png";
                    label2.Text = "Table Tech Money".ToString();
                    break;
                case 169:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Table_Tech_Rocket.png";
                    label2.Text = "Table Tech Rocket".ToString();
                    break;
                case 170:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Table_Tech_Rage.png";
                    label2.Text = "Table Tech Rage".ToString();
                    break;
                case 171:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Table_Tech_Blanks.png";
                    label2.Text = "Table Tech Blanks".ToString();
                    break;
                case 172:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Table_Tech_Stun.png";
                    label2.Text = "Table Tech Stun".ToString();
                    break;
                case 173:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Heart_Holster.png";
                    label2.Text = "Heart Holster".ToString();
                    break;
                case 174:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Heart_Lunchbox.png";
                    label2.Text = "Heart Lunchbox".ToString();
                    break;
                case 175:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Heart_Locket.png";
                    label2.Text = "Heart Locket".ToString();
                    break;
                case 176:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Heart_Bottle.png";
                    label2.Text = "Heart Bottle".ToString();
                    break;
                case 177:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Heart_Purse.png";
                    label2.Text = "Heart Purse".ToString();
                    break;
                case 178:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Ruby_Bracelet.png";
                    label2.Text = "Ruby Bracelet".ToString();
                    break;
                case 179:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Sixth_Chamber.png";
                    label2.Text = "Sixth Chamber".ToString();
                    break;
                case 180:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Coolant_Leak.png";
                    label2.Text = "Coolent Leak".ToString();
                    break;
                case 181:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Heart_of_Ice.png";
                    label2.Text = "Heart of Ice".ToString();
                    break;
                case 182:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Ancient_Hero's_Bandana.png";
                    label2.Text = "Acient Hero's Bandana".ToString();
                    break;
                case 183:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Bloodied_Scarf.png";
                    label2.Text = "Bloodied Scarf".ToString();
                    break;
                case 184:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Muscle_Relaxant.png";
                    label2.Text = "Muscle Relaxant".ToString();
                    break;
                case 185:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Hip_Holster.png";
                    label2.Text = "Hip Holster".ToString();
                    break;
                case 186:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Clone.png";
                    label2.Text = "Clone".ToString();
                    break;
                case 187:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Sponge.png";
                    label2.Text = "Sponge".ToString();
                    break;
                case 188:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Gas_Mask.png";
                    label2.Text = "Gas Mask".ToString();
                    break;
                case 189:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Hazmat_Suit.png";
                    label2.Text = "Hazmat Suit".ToString();
                    break;
                case 190:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Book_of_Chest_Anatomy.png";
                    label2.Text = "Book of Chest Anatomy".ToString();
                    break;
                case 191:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Gun_Soul.png";
                    label2.Text = "Gun Soul".ToString();
                    break;
                case 192:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Shelleton_Key.png";
                    label2.Text = "Shellton Key".ToString();
                    break;
                case 193:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Brick_of_Cash.png";
                    label2.Text = "Brick of Cash".ToString();
                    break;
                case 194:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Battle_Standard.png";
                    label2.Text = "Battle Standard".ToString();
                    break;
                case 195:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Wingman.png";
                    label2.Text = "Wingman".ToString();
                    break;
                case 196:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Wolf.png";
                    label2.Text = "Wolf".ToString();
                    break;
                case 197:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Dog.png";
                    label2.Text = "Dog".ToString();
                    break;
                case 198:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Owl.png";
                    label2.Text = "Owl".ToString();
                    break;
                case 199:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Super_Space_Turtle.png";
                    label2.Text = "Super Space Turtle".ToString();
                    break;
                case 200:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Junk.png";
                    label2.Text = "Junk".ToString();
                    break;
                case 201:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\R2G2.png";
                    label2.Text = "R2G2".ToString();
                    break;
                case 202:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Badge.png";
                    label2.Text = "Badge".ToString();
                    break;
                case 203:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Ser_Junkan_1.png";
                    label2.Text = "Ser Junkan".ToString();
                    break;
                case 204:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Chicken_Flute.png";
                    label2.Text = "Chicken Flute".ToString();
                    break;
                case 205:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Space_Friend.png";
                    label2.Text = "Space Friend".ToString();
                    break;
                case 206:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Pig.png";
                    label2.Text = "Pig".ToString();
                    break;
                case 207:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Blank_Companion's_Ring.png";
                    label2.Text = "Blank Companion's Ring".ToString();
                    break;
                case 208:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Briefcase_of_Cash.png";
                    label2.Text = "Briefcase of Cash".ToString();
                    break;
                case 209:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Galactic_Medal_of_Valor.png";
                    label2.Text = "Galactic Medal of Valor".ToString();
                    break;
                case 210:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Bullet_Idol.png";
                    label2.Text = "Bullet Idol".ToString();
                    break;
                case 211:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Riddle_of_Lead.png";
                    label2.Text = "Riddle of Lead".ToString();
                    break;
                case 212:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Bracket_Key.png";
                    label2.Text = "Bracket Key".ToString();
                    break;
                case 213:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Elder_Blank.png";
                    label2.Text = "Elder Blank".ToString();
                    break;
                case 214:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Teleporter_Prototype.png";
                    label2.Text = "Teleporter Prototype".ToString();
                    break;
                case 215:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Yellow_Chamber.png";
                    label2.Text = "Yellow Chamber".ToString();
                    break;
                case 216:

                    pictureBox2.ImageLocation = "C:\\Users\\User\\Pictures\\enter the gungeon\\items\\Chest _Teleporter.png";
                    label2.Text = "Chest Teleporter".ToString();
                    break;

            }

        }

    }
}
